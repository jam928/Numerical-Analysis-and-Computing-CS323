function y = f(x)
    y = exp(sin(x*5));
end