function[idx, C, sumD, D] = MyKmeans(X, K, C0, numIter)

    [N, M] = size(X) ; 
    idx = zeros(N,1); % this vector will be used for storing the index of closest centre
    D = zeros(N, K); % for N points this will store dis from K clusters
    C = C0;
    
    current = zeros(1, M);
    
    %total number of iterations that we need to perform
    for i = 1:numIter
        
        %for each point(x,y), find the cluster centroid having minum distance
        %from this point(x,y)
        for j = 1:N
            current = X(j,:); % this will give current point (x,y)
            D(j, :) = sum(((C - ones(K, 1) * current).^2), 2);
            
            %C0 = K * 2, i.e. K clusters in the form(x,y)
            %current is the current point (x,y)
        end
        %Now we need to figure out that each point belongs to which cluster
        [min_dis, idx] = min(D, [], 2);
        
        %Now we need to update our cluster centroids
        
        % for each cluster, we need to update it
        % we update each cluster by replacing it by centroid of the 
        % points belonging to the cluster
        for j = 1:K  
            z = (idx == j); % get the index of the points which belong to this cluster
            
            % replace jth centroid by average
            C(j, :) = sum(X(z)) / size(z, 1) ;
        end
        
    end
    
    sumD = zeros(K, 1);
    
    for i = 1:K
        for j = 1:N
            if(idx(j) == i)
                sumD(i) = sum( (X(j,:)-C(i,:)).^2 );
            end
        end
    end
    
end